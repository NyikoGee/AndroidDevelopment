 package com.example.s63843064;
/*
<> student number: s63843064
<> Name: Nyiko Gift Maluleke
<> Purpose: The purpose of this app is to create a small application
<> that a user can use to determine his/her average time for a marathon run.
<> it is developed in accordance with the specification for the module ICT2612


 */

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

 public class MainActivity extends AppCompatActivity {

     private int x;
     int hours = x * 60;
     private int y;
     int minutes = y ;
     private Object EditText;
     int totalTime;



     @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        final EditText minutes = findViewById(R.id.minutes);
        final EditText hours = findViewById(R.id.hours);
        final Button btnAverageTime = findViewById(R.id.btnAverageTime);
        Button btnClose = findViewById(R.id.btnClose);
        final TextView result = (TextView) findViewById(R.id.result);

        //coding the average button
        Button averageTime = (Button) findViewById(R.id.btnAverageTime);
        averageTime.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AverageTimeActivity.class);
                startActivity(intent);
                //the above code is to add the second screen to the button

                if (TextUtils.isEmpty(hours.getText().toString())) {
                    hours.setError("Enter Hours");
                    return;
                    //this will return the string specified if the field is empty and the button is selected
                }
                if (TextUtils.isEmpty(minutes.getText().toString())) {
                    minutes.setError("Enter Minutes");
                    return;
                    //this will return the string specified if the field is empty and the button is selected
                }
            }

        });
         btnClose = (Button) findViewById(R.id.btnClose);
        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Runtime.getRuntime();
            }
        });
    if (x > 600) {
        Toast.makeText(this, "Number cannot exceed 10 hours", Toast.LENGTH_SHORT).show();
    }
    if (y > 59 ) {
        Toast.makeText(this, "Minutes cannot exceed 59", Toast.LENGTH_SHORT).show();
    }
    }
}